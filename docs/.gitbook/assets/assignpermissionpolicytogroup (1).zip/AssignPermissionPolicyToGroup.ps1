<#

概述：这个脚本用来为一个组的所有成员设置AppPermissionPolicy. 目前这个Policy还无法直接按组分配，所以需要自定义脚本来实现。请参考对应的文章说明：https://teamsplatform.code365.xyz/it-prespective-of-the-platform/policy-based-managment

作者：陈希章 （code365@xizhang.com)
网站：https://teamsplatform.code365.xyz 

#>
[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]
    $GroupName,
    [Parameter(Mandatory = $true)]
    [string]
    $PolicyName
)

# 连接
Import-Module MicrosoftTeams
Import-Module Az.Resources

Connect-MicrosoftTeams
Connect-AzAccount

# 查找组成员 
Function Get-RecursiveAzureAdGroupMemberUsers {
    [cmdletbinding()]
    param(
        [parameter(Mandatory = $True, ValueFromPipeline = $true)]
        $AzureGroup
    )
    Begin {
        
    }
    Process {
        Write-Verbose -Message "枚举组成员 $($AzureGroup.DisplayName)"
        $Members = Get-AzADGroupMember -GroupObjectId $AzureGroup.Id
            
        $UserMembers = $Members | Where-Object { $_.ObjectType -eq 'User' }
        If ($Members | Where-Object { $_.ObjectType -eq 'Group' }) {
            [array]$UserMembers += $Members | Where-Object { $_.ObjectType -eq 'Group' } | ForEach-Object { Get-RecursiveAzureAdGroupMemberUsers -AzureGroup $_ }
        }
    }
    end {
        Return $UserMembers
    }
}

# 设置组成员权限策略
$group = Get-AzADGroup -DisplayName $GroupName
$members = Get-RecursiveAzureAdGroupMemberUsers -AzureGroup $group | Where-Object { $_.ObjectType -eq "User" }
$members | ForEach-Object { Write-Host "为 $($_.UserPrincipalName) 设置策略"; Grant-CsTeamsAppPermissionPolicy -PolicyName $PolicyName -Identity $_.UserPrincipalName }

Write-Host "完全配置"